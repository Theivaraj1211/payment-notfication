const express = require('express')
const { port } = require('./utils/config')

const notificationRouter = require('./src/routes/payment.router')

const app = express()

const PORT = port

app.use(express.json())

app.use('/api/v1/payments', notificationRouter)

app.listen(PORT, () => {
    console.log(`Express is running at ${PORT}`)
})
