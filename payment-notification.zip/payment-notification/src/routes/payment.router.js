const express = require("express");
const notificationController = require("../controllers/payment.controller");

const paymentRouter = express.Router();

paymentRouter.post("/notifications", notificationController.postNotification);

module.exports = paymentRouter;
