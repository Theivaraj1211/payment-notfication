const crypto = require('crypto')

function postNotification(req, res) {
    console.log(req.body)
    var secretFromConfiguration = req.body.secretFromConfiguration

    // Data from server
    var ivfromHttpHeader = req.body.ivfromHttpHeader
    var authTagFromHttpHeader = req.body.authTagFromHttpHeader
    var httpBody = req.body.httpBody

    // Convert data to process
    var key = new Buffer(secretFromConfiguration, 'hex')
    var iv = new Buffer(ivfromHttpHeader, 'hex')
    var authTag = new Buffer(authTagFromHttpHeader, 'hex')
    var cipherText = new Buffer(httpBody, 'hex')

    // Prepare descryption
    var decipher = crypto.createDecipheriv('aes-256-gcm', key, iv)
    decipher.setAuthTag(authTag)

    // Decrypt
    var result = decipher.update(cipherText) + decipher.final()

    console.log(result)
    res.status(200).json(result)
}

module.exports = {
    postNotification,
}
